#include<stdio.h>
void main()
{
        int b = a*b;
        while( a > b ){
                a = a+1;
        }
        if( b < = c ){
                a = 10;
        }
        else{
                a = 20;
        }
        a = 100;
	for(i=0;i<10;i = i+1){
	        a = a+1;
	}
	(x < b) ? x = 10 : x=11;
	
}
