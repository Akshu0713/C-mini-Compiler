#include<stdio.h>
void main()
{
	int s=1+2+3+4;
	while(x>10){
		while(x>10){
			x = 0;
			cout<<"ejnfoejnfo"<<endl ;
      if(x>0){
    		y=1;
    	}
    	else{
    		y=2;
    	}
		}
    for(i=0;i<n;i++){
  		cout<<"ejnfoejnfo"<<endl ;
  	}
		x = 0;
	}
	if(x>0){
		y=1;
    if(x>0){
  		y=1;
  	}
  	else{
  		y=2;
  	}
	}
	else{
		y=2;
    if(x>0){
  		y=1;
  	}
  	else{
  		y=2+3;
  	}
	}
	if(x>0){
		y=1;
	}
	cout<<"ejnfoejnfo" ;
	for(i=0;i<n;i++){
		cout<<"ejnfoejnfo"<<endl ;
	}
	(s >= 2) ? y=0 : y=1;
}
